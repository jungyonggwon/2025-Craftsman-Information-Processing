#include <stdio.h>
main( ) {
	printf("%d", -5 & 7);
	return 0;
}