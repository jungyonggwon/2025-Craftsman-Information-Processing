#include <stdio.h>
main() {
	int num1 = 16, num2 = 44;
	int a = num1++;
	int b = --num2;
	printf("%d", a + b);
}