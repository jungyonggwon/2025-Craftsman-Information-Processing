main() /*1.1 Version by Kang*/
{
	int abc_1;
	int 1abc;
	int Kim;
	int kim;
	int for;
	char kang
}