#include <stdio.h>
int main()
{
	int a = 15;
	printf("%o", a);
	return 0;
}