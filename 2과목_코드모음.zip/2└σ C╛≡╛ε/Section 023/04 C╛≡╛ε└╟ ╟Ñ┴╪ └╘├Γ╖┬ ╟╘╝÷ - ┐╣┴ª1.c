#include <stdio.h>
main()
{
	int i, j;
	float aa;
	char cc, dd[10];
	scanf("%c\n", &cc);
	scanf("%d %o", &i, &j);
	scanf("%f", &aa);
	scanf("%s", dd);
}