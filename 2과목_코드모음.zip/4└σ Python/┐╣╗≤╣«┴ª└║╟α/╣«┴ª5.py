a = "What's this?"
print("%-10.4s" % a)
print("%10.4s" % a)