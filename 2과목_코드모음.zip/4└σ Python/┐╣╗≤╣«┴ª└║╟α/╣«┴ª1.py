class Employee:
    name = '홍길동'
    idNum = 17001
    salary = 4500000
    sex = True sex
a = Employee()
print(a.name)
print(a.idNum)
print(a.salary)
print(a.sex)