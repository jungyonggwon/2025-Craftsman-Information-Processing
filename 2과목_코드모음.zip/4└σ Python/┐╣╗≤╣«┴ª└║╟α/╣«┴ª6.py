hap1 = 10 + 10 % 4 - 10 % 9
hap2 = 10 * 10 % 4 - 10 % 9 + 5
print("%d, %d" % (hap1, hap2))