i, hap = 1, 0
while i <= 6:
	hap += i
	i += 2
print(f"i={i}, hap={hap}")