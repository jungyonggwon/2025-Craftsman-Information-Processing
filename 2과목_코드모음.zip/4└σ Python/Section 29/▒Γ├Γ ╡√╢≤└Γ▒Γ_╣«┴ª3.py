i = 20
f = 123456.789E-3
print('%d\n%d' % (i, i), end = '/')
print('%.3f' % f)