a, b = 10, 20
if a > b:
	cha = a - b
	print(cha)
else:
	cha = b - a
	print(cha)