import java.math.*;
public class Test
{
	public static void main(String[] args) {
	BigInteger n = new BigInteger("12345");
	BigInteger m = new BigInteger("54321");
	System.out.print(n.compareTo(m));
	}
}