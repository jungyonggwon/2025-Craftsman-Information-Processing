#define _USE_MATH_DEFINES
#include <stdio.h>
#include <math.h>
main() {
	printf("%.2f", M_PI);
	return 0;
}