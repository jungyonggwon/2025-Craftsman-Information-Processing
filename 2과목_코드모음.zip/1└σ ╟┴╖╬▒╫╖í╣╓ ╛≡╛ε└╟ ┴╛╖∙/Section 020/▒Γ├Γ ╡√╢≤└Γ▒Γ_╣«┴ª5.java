public class Main
{
	public static void main(String[] args) {
		String teststr = " LoremIpsum ";
		int a = teststr.trim( ).length( );
		System.out.print(a);
	}
}