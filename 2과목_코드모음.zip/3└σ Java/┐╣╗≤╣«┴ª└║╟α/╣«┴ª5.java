public class Test {
	public static void main(String[] args) {
		int a = sum(3, 4);
		System.out.println(a);
	}
	public static int sum(int a, int b) {
		int sum;
		return sum = a + b;
	}
}