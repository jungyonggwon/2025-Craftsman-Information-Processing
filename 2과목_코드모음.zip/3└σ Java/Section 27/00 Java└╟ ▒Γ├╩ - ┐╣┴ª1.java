public class Problem
{
	public static void main (String[] args){
		int i , j = 0;
		for (i = 1; i < 8; i++)
		{
			j = j + i;
		}
		System.out.printf("%d, %d", i, j);
	}
}